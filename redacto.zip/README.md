### Redacto
Redacting the Internet, one page at a time...



<img width=48 src="https://raw.githubusercontent.com/dhowe/Redacto/master/icon48.png"/>

Help test Redacto for Chrome beta: with [developer-mode](http://rednoise.org/img/devmode.png) enabled, 
download [this file](https://github.com/dhowe/Redacto/releases/download/v1.0/redacto.crx.zip), unzip, and drag into Chrome


